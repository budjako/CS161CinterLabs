<h2>.OBJ Parser</h2>

<b>Summary:</b>
<<<<<<< HEAD
<<<<<<< HEAD
<<<<<<< HEAD
This is a .obj parser that is used to bring in outside models and integrate directly to native WebGL.
=======
This is a .obj parser that is used to bring in outside models and integrate directly to native WebGL. Here is some great documentation that I was using for parsing the .OBJ file -> http://www.martinreddy.net/gfx/3d/OBJ.spec
>>>>>>> parent of c6a5ab2... Update README.md
=======
This is a .obj parser that is used to bring in outside models and integrate directly to native WebGL. 

Here is some great documentation that I was using for parsing the .OBJ file -> http://www.martinreddy.net/gfx/3d/OBJ.spec
>>>>>>> 3d1d403ccc7082fcc42f24f035619a50bd32d6aa
=======
This is a .obj parser that is used to bring in outside models and integrate directly to native WebGL. 

Here is some great documentation that I was using for parsing the .OBJ file -> http://www.martinreddy.net/gfx/3d/OBJ.spec
>>>>>>> 3d1d403ccc7082fcc42f24f035619a50bd32d6aa

<b>To-Do:</b>
<ul>
  <li>Abstract out parser to work for more than just WebGL</li>
  <li>Make parser compatible vertex normals for lighting</li>
  <li>Make parser handle colors in substitute of textures (more on the program side)</li>
</ul>
